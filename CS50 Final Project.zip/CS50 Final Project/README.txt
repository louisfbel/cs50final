Welcome to Woodfire!

To run the game, you may have to download Godot (for free) and run the game from 
the editor. This way, you can see all the scenes and code used in my game.
Most of my work has been compiled into the World.tscn scene, but clicking
through other scenes will reveal more snippets of connect code.

In this game, you will run around using w a s d, sprint using shift, 
attack using space, and interact with objects using e. The goal is to find and explode
all gas stations scattered across the map. Along the way, you can punch airplanes
shooting greenhouses at you to level up. You will have to find two keys to unlock the
gas stations as well as win one race and build enough strength through leveling up
to break down one gate in the southwest corner.

The hitboxes for attacking are somewhat finicky. In order to damage the plane 
enemies or interact with entities, you have to press the attack or interact key
before moving into the enemy or entity. For that reason, it is easiest to attack 
enemies while running.

Here is my YouTube video:  https://youtu.be/SHWMWGAJttY 

